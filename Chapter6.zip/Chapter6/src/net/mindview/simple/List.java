package net.mindview.simple;

public class List {
    public List(){
        System.out.println("net.mindview.simple.List");
    }
}
