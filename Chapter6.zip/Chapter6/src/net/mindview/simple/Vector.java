package net.mindview.simple;

public class Vector {
    public Vector(){
        System.out.println("net.mindview.simple.Vector");
    }
}
