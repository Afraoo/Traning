package access;

import access.dessert.Cookie;

public class Dinner {
    public static void main(String[] args){
        Cookie x = new Cookie();

    }
}
