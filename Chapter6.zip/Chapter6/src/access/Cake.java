package access;

public class Cake {
    public static void main(String[] args){
        Pie x = new Pie();
        x.f();
    }
}
