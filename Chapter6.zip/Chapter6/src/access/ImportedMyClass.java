package access;

import access.mypackage.MyClass;

public class ImportedMyClass {
    public static void main(String[] args){
        MyClass m = new MyClass();
    }
}
