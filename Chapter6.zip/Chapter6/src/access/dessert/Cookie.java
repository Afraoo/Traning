package access.dessert;

public class Cookie {
    public Cookie(){
        System.out.println("Cookie constructor");
    }
}
