package access;

public class Pie {
    void f(){
        System.out.println("Pie.f()");
    }
}
